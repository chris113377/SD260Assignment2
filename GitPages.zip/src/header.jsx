import React from 'react';

const Header = () => {
  return ( 
    <h1 className="app-header">Which Game would you most likely play on PC?</h1>
   );
}
 
export default Header;